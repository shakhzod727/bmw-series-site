
// next.config.js
module.exports = {
  reactStrictMode: true,
};
