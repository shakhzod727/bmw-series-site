
import Link from 'next/link'
import { motion } from 'framer-motion'

const cars = [
  { name: 'BMW M4 Competition', slug: 'm4-competition', image: '/images/m4.jpg' },
  { name: 'BMW M5 Competition', slug: 'm5-competition', image: '/images/m5.jpg' },
  { name: 'BMW M8 Gran Coupe', slug: 'm8-gran-coupe', image: '/images/m8.jpg' },
  { name: 'BMW M2 CS', slug: 'm2-cs', image: '/images/m2.jpg' },
  { name: 'BMW M3 CSL', slug: 'm3-csl', image: '/images/m3.jpg' }
]

export default function Home() {
  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-8 text-center">BMW M Series</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {cars.map(car => (
          <motion.div key={car.slug} whileHover={{ scale: 1.05 }} className="bg-gray-800 rounded-xl overflow-hidden shadow-lg">
            <img src={car.image} alt={car.name} className="w-full h-56 object-cover" />
            <div className="p-4">
              <h2 className="text-2xl font-semibold">{car.name}</h2>
              <Link href={`/cars/${car.slug}`} className="text-blue-400 hover:underline">
                View Details
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
