
import { useRouter } from 'next/router'
import { motion } from 'framer-motion'
import Link from 'next/link'

const carData = {
  'm4-competition': { name: 'BMW M4 Competition', image: '/images/m4.jpg', desc: 'High-performance coupe with stunning design.' },
  'm5-competition': { name: 'BMW M5 Competition', image: '/images/m5.jpg', desc: 'Luxury sedan with track-ready performance.' },
  'm8-gran-coupe': { name: 'BMW M8 Gran Coupe', image: '/images/m8.jpg', desc: 'Four-door coupe combining luxury and speed.' },
  'm2-cs': { name: 'BMW M2 CS', image: '/images/m2.jpg', desc: 'Compact sports car with incredible agility.' },
  'm3-csl': { name: 'BMW M3 CSL', image: '/images/m3.jpg', desc: 'Lightweight performance legend reborn.' }
}

export default function CarPage() {
  const router = useRouter()
  const { model } = router.query
  const car = carData[model]

  if (!car) return <p>Car not found</p>

  return (
    <div className="p-8">
      <Link href="/" className="text-blue-400 hover:underline">← Back</Link>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="mt-4">
        <h1 className="text-4xl font-bold mb-4">{car.name}</h1>
        <img src={car.image} alt={car.name} className="w-full rounded-xl shadow-lg mb-4" />
        <p className="text-lg">{car.desc}</p>
      </motion.div>
    </div>
  )
}
