import Link from "next/link";
import { motion } from "framer-motion";

export default function Home() {
  const cars = [
    {
      name: "BMW M4 Competition",
      img: "https://www.bmwusa.com/content/dam/bmwusa/MY24/m4/2024-bmw-m4-coupe-stage1-desktop.jpg",
      slug: "m4"
    },
    {
      name: "BMW M5 Competition",
      img: "https://www.bmwusa.com/content/dam/bmwusa/MY21/m5/2021-BMW-M5-Competition-Sedan-Overview-01.jpg",
      slug: "m5"
    },
    {
      name: "BMW M8 Gran Coupe",
      img: "https://www.bmwusa.com/content/dam/bmwusa/MY22/m8-gran-coupe/2022-bmw-m8-gran-coupe-stage1-desktop.jpg",
      slug: "m8"
    },
    {
      name: "BMW M2 CS",
      img: "https://cdn.bmwblog.com/wp-content/uploads/2020/03/bmw-m2-cs-03.jpg",
      slug: "m2"
    },
    {
      name: "BMW M3 CSL",
      img: "https://cdn.bmwblog.com/wp-content/uploads/2022/05/BMW-M4-CSL-photos-30.jpg",
      slug: "m3"
    }
  ];

  return (
    <div className="min-h-screen px-6 py-10">
      <h1 className="text-white text-4xl font-bold text-center mb-10">
        BMW M Seriyasi 🚗💨
      </h1>

      <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3 max-w-6xl mx-auto">
        {cars.map((car, i) => (
          <motion.div
            key={i}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white rounded-2xl overflow-hidden shadow-lg"
          >
            <img
              src={car.img}
              alt={car.name}
              className="w-full h-56 object-cover"
            />
            <div className="p-4">
              <h2 className="text-lg font-semibold mb-3">{car.name}</h2>
              <Link href={`/cars/${car.slug}`}>
                <button className="bg-blue-600 hover:bg-blue-800 text-white px-4 py-2 rounded-lg transition">
                  Batafsil
                </button>
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
