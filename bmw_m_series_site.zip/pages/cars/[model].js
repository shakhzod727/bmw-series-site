import { useRouter } from "next/router";
import Link from "next/link";
import { motion } from "framer-motion";

export default function CarDetail() {
  const router = useRouter();
  const { model } = router.query;

  const carData = {
    m4: {
      name: "BMW M4 Competition",
      img: "https://www.bmwusa.com/content/dam/bmwusa/MY24/m4/2024-bmw-m4-coupe-stage1-desktop.jpg",
      desc: "503 ot kuchiga ega sport kupe, zamonaviy dizayn va yuqori tezlikka mo‘ljallangan."
    },
    m5: {
      name: "BMW M5 Competition",
      img: "https://www.bmwusa.com/content/dam/bmwusa/MY21/m5/2021-BMW-M5-Competition-Sedan-Overview-01.jpg",
      desc: "Sedan qulayligi va M seriyasining kuchini birlashtirgan sport avtomobil."
    },
    m8: {
      name: "BMW M8 Gran Coupe",
      img: "https://www.bmwusa.com/content/dam/bmwusa/MY22/m8-gran-coupe/2022-bmw-m8-gran-coupe-stage1-desktop.jpg",
      desc: "Lux va tezlik uyg‘unligi, 617 ot kuchiga ega grand turer."
    },
    m2: {
      name: "BMW M2 CS",
      img: "https://cdn.bmwblog.com/wp-content/uploads/2020/03/bmw-m2-cs-03.jpg",
      desc: "Kichik hajmli, ammo kuchli sport kupe, engil va chaqqon."
    },
    m3: {
      name: "BMW M3 CSL",
      img: "https://cdn.bmwblog.com/wp-content/uploads/2022/05/BMW-M4-CSL-photos-30.jpg",
      desc: "Engil, cheklangan nashr, yuqori performans va track uchun yaratilgan."
    }
  };

  const car = carData[model];

  if (!car) return <p className="text-white p-6">Model topilmadi...</p>;

  return (
    <div className="min-h-screen px-6 py-8 text-white">
      <Link href="/">
        <button className="bg-white text-blue-600 px-4 py-2 rounded-lg mb-6">
          ← Orqaga
        </button>
      </Link>

      <motion.h1
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-3xl font-bold mb-4"
      >
        {car.name}
      </motion.h1>

      <motion.img
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        src={car.img}
        alt={car.name}
        className="rounded-xl shadow-lg max-w-3xl w-full mb-6"
      />

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="max-w-3xl"
      >
        {car.desc}
      </motion.p>
    </div>
  );
}
